import streamlit as st

from src.components.dialog_attendance_results import show_attendance_result
from src.components.voice_capture import voice_capture
from src.database.db import DatabaseError, get_enrolled_students, get_voice_gallery
from src.pipelines.voice_pipeline import VoiceError, process_bulk_audio_detailed
from src.settings import VOICE_MATCH_THRESHOLD
from src.services.attendance import build_review_session, new_session_timestamp, voice_review_inputs
from src.validation import ValidationError, decode_audio_base64


def _analyze_voice_sample(subject_id: int, capture: dict) -> None:
    try:
        audio_bytes = decode_audio_base64(capture.get("audio_base64", ""))
    except ValidationError as exc:
        st.error(str(exc))
        return

    try:
        with st.spinner("Processing audio…"):
            enrolled = get_enrolled_students(st.session_state.teacher_data["teacher_id"], subject_id)
            if not enrolled:
                st.warning("No students are enrolled in this subject.")
                return
            candidates = {s["student_id"]: s["voice_embedding"] for s in enrolled if s.get("voice_embedding")}
            if not candidates:
                st.error("None of the enrolled students has a voice profile.")
                return
            cohort = {int(r["student_id"]): r["voice_embedding"] for r in get_voice_gallery()}
            result = process_bulk_audio_detailed(audio_bytes, candidates, cohort=cohort)
    except (VoiceError, DatabaseError) as exc:
        st.error(str(exc))
        return
    except ImportError:
        st.error("Voice recognition is not installed on this server (see README: resemblyzer).")
        return

    if result.segments == 0:
        st.info("No clear response was detected. Have each student say ‘Present, ma’am’ alone, with a short pause before and after.")
        return
    if not result.matched and not result.ambiguous:
        best = max(result.best_scores, default=0.0)
        st.info(
            f"No voice was confidently identified, so attendance was not created. "
            f"The best profile similarity was {best:.2f}; this app requires {VOICE_MATCH_THRESHOLD:.2f}. "
            "Have each student re-record their voice profile (the full prompt, at least 3 seconds of speaking), "
            "then record students one at a time with a pause between speakers. You can also use classroom photos."
        )
        return
    if result.ambiguous:
        st.info(
            f"{len(result.ambiguous)} speaking turn(s) were too similar to multiple voice profiles. "
            "Check that each student recorded their own voice profile; those rows are marked for review."
        )
    for issue in (result.quality.issues if result.quality else []):
        st.warning(issue)

    present, matched_scores, notes = voice_review_inputs(enrolled, result)
    st.session_state.voice_attendance_results = build_review_session(
        enrolled, present, subject_id, new_session_timestamp(),
        scores=matched_scores, review_notes=notes, method="voice",
    )


@st.dialog("Voice attendance", width="large")
def voice_attendance_dialog(subject_id):
    st.write("Record students one at a time, with a short pause between speakers. Ask each student to say this full sentence clearly (about 3 seconds): “Present, ma’am. I am here in the class today.” Leave about a second of silence before the next student. Overlapping voices cannot be identified reliably.")
    capture = voice_capture(key="teacher_voice_attendance_capture", action_label="Analyze audio")
    if isinstance(capture, dict) and capture.get("submitted"):
        request_id = capture.get("request_id")
        if request_id != st.session_state.get("teacher_voice_attendance_request"):
            st.session_state.teacher_voice_attendance_request = request_id
            st.session_state.voice_attendance_results = None
            _analyze_voice_sample(subject_id, capture)

    if st.session_state.get("voice_attendance_results"):
        st.divider()
        df, logs = st.session_state.voice_attendance_results
        show_attendance_result(df, logs)
